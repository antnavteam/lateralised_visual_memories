

%% Make id_ talbe, with one row per file, all test rotations on the same line


    filename = {};
    cond = {};
    ant = [];
    data={};
    mirror={};
    
d=dir('Tr*'); %get the folder for the different group
i=0;

for f=1:length(d)
    
cur_groupname = d(f).name;
cd([basedir, cur_groupname])

d2=dir('ant*');

    for a=1:length(d2); i=i+1; % iterate on each ants of the group (keep i increasing across groups)
       
       filename{i,1} = d2(a).name;
       cond{i,1}= cur_groupname;
       ant(i,1)=i; % give each ant a different number (will not fit with filename)

       csv_data_raw = dlmread([filename{i}],',',1,0);

       %Take the Derivative data
       csv_data = csv_data_raw (2:end,2:5) - csv_data_raw (1:end-1,2:5);

       data{i,1} = csv_data;
       mirror{i,1} = csv_data_raw(1:end-1,6); % add the mirror indexes

    end
end

cd(basedir);
save('miror_data_fordynamics.mat','filename','ant','cond','data','mirror')