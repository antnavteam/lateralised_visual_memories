
frame_before_p = 150; %in fps, p flag the moment where the  ring surrounding the ant is being lifted

cd([basedir '/antclock_data'])



%% Make id_ talbe, with one row per file, all test rotations on the same line

d=dir('*_all.ant');
rot_list = [0 45 -45 90 -90 135 -135 180];


id_filename = {};
id_cond = {};
id_ant = [];
id_rot_goal = [];
id_data_per_rot = {};

for i=1:length(d)
    
   id_filename{i,1}= d(i).name(1:23);
   id_cond{i,1}= d(i,1).name(12);
   id_ant(i,1)=str2num(d(i).name(9:10));
   id_rot_goal(i,1)=str2num(d(i).name(13:16));
   
   
   csv_data_raw = dlmread([id_filename{i} ,'_all.ant'],';',1,0);
   
   %Take the Derivative data
   csv_data = csv_data_raw (2:end,2:5) - csv_data_raw (1:end-1,2:5);
    
   
   csv_p = dlmread([id_filename{i} ,'_p.ant'],';',1,0);
   % Check that the number of p is 16 (beg and end of the 8 rotations)
   ps=(csv_p(:,1)); % number of time p was pressed

   if length(ps) == 15 %finish recording with escape
       ps(16,1) = csv_data_raw(end,1); %so make the 16's index as end of the file
   elseif length(ps)~= 16
       warning([id_filename{i} ': number of p=' num2str(length(ps))])
   end
       
   % ----Get beg and end index for each rot
       k=0;
       for j=1:2:15
           k=k+1;
           p(k,1)=ps(j); %mark the begining
           p(k,2)=ps(j+1); %mark the end
       end
       
    % -----Get data for each rot   
       
    for j=1:length(p)
        id_data_per_rot{i,j} = csv_data(p(j,1)-frame_before_p : p(j,2) , :);
    end
     
end

%% from previous table, make a table with one row per test

filename = {}; 
ant = [];
cond = {}; % R=route U=unfam
rot_deg = []; %current faced angle compared to correct dir
data = {}; % data from trackball
seq_nb=[]; % order of the current rotation (1:16 both cond) = proxy for time spent on the ball by the ant

k=0;
for i=1:length(id_ant)
    
    for j=1:length(rot_list)
        k=k+1;
        
        cur_rot = rot_list(j);
        
        ant(k,1) = id_ant(i);
        cond{k,1} = id_cond{i};
        filename{k,1} = id_filename{i};
        
        rot_deg(k,1) = cur_rot - id_rot_goal(i); % get the current rotation away from the goal
        data{k,1} = id_data_per_rot{i,j};
        
        % get sequence nb, odd ant were tested on R first, even ant on U first
        if ceil(id_ant(i)/2) ~= id_ant(i)/2 && id_cond{i}== 'U'  % check if odd ant number and unfam
            seq_nb(k,1)=j+8;
        elseif ceil(id_ant(i)/2) == id_ant(i)/2 && id_cond{i}== 'R'  % check if even ant number and route
            seq_nb(k,1)=j+8;
        else
            seq_nb(k,1)=j;
        end
            
    end
end

rot = pi2pi(rot_deg/180*pi);

cd(basedir)
save('Myrmecia_data.mat','filename','ant','cond','rot','seq_nb','data','frame_before_p')
